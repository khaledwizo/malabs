package com.azyaa.app

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.net.URLEncoder

/** أزياء البنات: يعرض صور جوجل للإطلالة المختارة داخل نافذة بالتطبيق (البحث الآمن مقفول) */
class MainActivity : AppCompatActivity() {

    // الإطلالة (عربي -> كلمة البحث)
    private val styles = linkedMapOf(
        "محجبات" to "hijab fashion outfit",
        "عباية" to "abaya fashion",
        "محتشم" to "modest fashion outfit",
        "فساتين" to "women dress fashion",
        "جامعي" to "university outfit women",
        "كاجوال" to "women casual outfit",
        "رسمي / عمل" to "women business attire",
        "سهرة" to "evening gown fashion",
        "رياضي" to "women sportswear outfit",
        "شتوي" to "women winter coat outfit",
        "تراثي" to "traditional dress fashion"
    )

    // الأوضاع لنفس الإطلالة
    private val modes = linkedMapOf(
        "الكل" to "",
        "ستوديو" to "studio photo",
        "شارع" to "street style",
        "إطلالة كاملة" to "full body",
        "تفاصيل" to "details close up"
    )

    // كلمات عشوائية حتى تتبدل النتائج مع كل تحديث
    private val variations = listOf(
        "", "black", "white", "beige", "pink", "blue", "green", "red", "brown",
        "elegant", "simple", "trendy", "2026", "summer", "spring", "autumn", "classy"
    )

    private lateinit var spStyle: Spinner
    private lateinit var spMode: Spinner
    private lateinit var web: WebView
    private lateinit var progress: ProgressBar
    private lateinit var txtCredit: TextView
    private lateinit var btnOpen: Button
    private lateinit var ads: Ads
    private var lastVariation = ""

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        spStyle = findViewById(R.id.spStyle)
        spMode = findViewById(R.id.spMode)
        web = findViewById(R.id.web)
        progress = findViewById(R.id.progress)
        txtCredit = findViewById(R.id.txtCredit)
        btnOpen = findViewById(R.id.btnOpen)

        spStyle.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, styles.keys.toList())
        spMode.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, modes.keys.toList())

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(v: WebView?, url: String?, f: Bitmap?) { progress.visibility = View.VISIBLE }
            override fun onPageFinished(v: WebView?, url: String?) { progress.visibility = View.GONE }
        }

        ads = Ads(this).also { it.init() }

        findViewById<Button>(R.id.btnSearch).setOnClickListener {
            ads.showRewardedInterstitial { load(randomize = false) }
        }
        findViewById<Button>(R.id.btnRefresh).setOnClickListener {
            if (web.url == null) { load(false); return@setOnClickListener }
            ads.showRewardedVideo(
                onReward = { load(randomize = true) },
                onNotWatched = { Toast.makeText(this, "شاهد الإعلان كاملاً حتى تتحدث الصور", Toast.LENGTH_SHORT).show() }
            )
        }
        btnOpen.setOnClickListener {
            web.url?.let { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it))) }
        }
    }

    private fun load(randomize: Boolean) {
        val s = styles[spStyle.selectedItem as String] ?: ""
        val m = modes[spMode.selectedItem as String] ?: ""
        var v = ""
        if (randomize) {
            do { v = variations.random() } while (v == lastVariation && variations.size > 1)
            lastVariation = v
        }
        val q = "$s $m $v".trim().replace(Regex("\\s+"), " ")
        // safe=active: البحث الآمن مقفول دائماً، tbm=isch: صور جوجل
        val url = "https://www.google.com/search?tbm=isch&safe=active&hl=ar&q=" +
                URLEncoder.encode(q, "UTF-8")
        web.loadUrl(url)
        txtCredit.text = "${spStyle.selectedItem} • ${spMode.selectedItem}" + if (v.isNotEmpty()) " • $v" else ""
        btnOpen.isEnabled = true
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
